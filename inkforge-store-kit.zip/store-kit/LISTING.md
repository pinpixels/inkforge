# Chrome Web Store: copy-paste text for every field

Copy each block into the matching field in the Developer Dashboard.

---

## Store listing tab

**Name** (comes from the ZIP, don't type it):
`Inkforge: PDF & Markdown to Article Converter`

**Summary** (comes from the ZIP):
`Turn PDFs & Markdown into polished Medium-ready articles with modern PNG diagrams. Independent tool, not affiliated with Medium.`

**Description** (paste this):

```
Inkforge turns your PDFs and Markdown files into polished, ready-to-publish articles for Medium writers, with every diagram, table and code block redrawn as a crisp, modern image.

WHY
Medium can't display tables, ASCII diagrams, Mermaid charts or highlighted code, and PDFs lose their structure when you copy them. Inkforge rebuilds that structure and redraws the visuals, so your article looks designed rather than pasted.

WHAT IT DOES
• Imports PDF, Markdown, text and HTML files, or paste text straight from Google Docs, Word, Notion or any web page, with headings, lists, tables, links and images kept
• Recovers headings, bold text, callouts, lists, tables and code from PDFs, including indentation
• Rebuilds ASCII and box-drawing diagrams, even when a PDF flattened them into one line
• Redraws diagrams, tables, code, file trees and cover images as 1400 px Retina PNGs in 5 themes
• Diagram Studio: edit any diagram as plain text with a live preview
• Tag Radar: suggests a 5-tag mix (broad, best-fit and niche) based on your article
• Medium-friendly formatting: two heading levels, split long paragraphs, captions, alt text, read time
• Paste panel: opens a new story with every part listed, ready to insert or copy one by one
• Copy as rich text for Medium, Substack, Ghost or LinkedIn, or publish to your own GitHub Pages first
• Built-in step-by-step help guide, version notes and update notices
• Optional AI help with your own key (Claude, OpenAI-compatible or local Ollama), with an automatic AI-disclosure line

PRIVATE BY DESIGN
Everything runs in your browser. No account, no tracking, no server. Inkforge sends nothing to its developer. Optional features talk only to the services you configure.

FREE
Inkforge is free. If it saves you time, there's an optional "Buy me a coffee" link.

Inkforge is an independent tool by PinPixels and is not affiliated with, endorsed by, or sponsored by Medium.
```

**Category:** Productivity → *Tools* (or the closest "Productivity" option shown)

**Language:** English

**Graphic assets** (all in `images/`):
| Field | File |
|---|---|
| Store icon (128×128) | `store-icon-128.png` |
| Screenshots (1280×800, upload all 5 in this order) | `screenshot-01-convert…`, `02-diagrams`, `03-editor`, `04-tags`, `05-publish` |
| Small promo tile (440×280) | `promo-small-440x280.png` |
| Marquee promo tile (1400×560) | `promo-marquee-1400x560.png` |

**Official URL / Homepage URL:** your GitHub Pages site, for example `https://YOUR-GITHUB-NAME.github.io/inkforge/`
**Support URL:** the same site, or your support email

---

## Privacy tab

**Single purpose description:**
```
Inkforge converts a user's own PDF or Markdown documents into a formatted article with redrawn images, and helps the user paste that article into a blog editor such as Medium.
```

**Permission justifications:**

| Permission | Justification (paste) |
|---|---|
| `sidePanel` | `The extension's interface (import, style, review, publish) runs in Chrome's side panel.` |
| `storage` | `Saves the user's settings and recent articles locally on their device so work isn't lost when the panel closes.` |
| `unlimitedStorage` | `Articles contain high-resolution generated images (several MB), which exceed the default local storage quota.` |
| `clipboardWrite` | `Lets the user copy the finished article (rich text or Markdown) and individual images to paste into their blog editor.` |
| `contextMenus` | `Adds a "Convert selection with Inkforge" right-click option for selected text.` |
| Host permission: `api.github.com` | `Optional feature: uploads the user's images/article to the user's own GitHub repository using the token they provide.` |
| Host permission: `api.anthropic.com`, `api.openai.com` | `Optional feature: sends article text to the AI provider the user chooses, with their own API key, to suggest headlines, tags and diagram fixes.` |
| Host permission: `localhost:11434`, `127.0.0.1:11434` | `Optional feature: connects to the user's own local Ollama AI server.` |
| Optional host permissions (`https://*/*`, `http://*/*`) | `Requested at runtime only if the user enters a custom AI endpoint (for example, a self-hosted OpenAI-compatible server). Never requested otherwise.` |
| Content script on `medium.com` | `Shows a paste panel inside the user's own new-story draft so they can insert their article piece by piece. It does not read or collect page data.` |

**Are you using remote code?** → **No, I am not using remote code.**
(All libraries are bundled inside the ZIP.)

**Data usage:** don't tick any of the data-type boxes. Inkforge doesn't collect user data, since nothing is sent to you, the developer. Then tick all three certifications:
- ☑ I do not sell or transfer user data to third parties, outside of the approved use cases
- ☑ I do not use or transfer user data for purposes that are unrelated to my item's single purpose
- ☑ I do not use or transfer user data to determine creditworthiness or for lending purposes

**Privacy policy URL:** `https://YOUR-GITHUB-NAME.github.io/inkforge/privacy.html`

---

## Distribution tab

- **Payments:** Free of charge
- **Visibility:** Public (or *Unlisted* for a quiet first test, where only people with the link can find it)
- **Regions:** All regions

## Test instructions tab

```
No login needed. Click the toolbar icon to open the side panel, drop any PDF or .md file (or paste Markdown and click "Convert text"), then use Style → Review → Publish. AI and GitHub features are optional and stay off until configured in Settings.
```
