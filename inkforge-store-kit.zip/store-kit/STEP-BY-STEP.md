# Launch Inkforge: step by step

Four parts, about 1–2 hours of your time in total, plus Google's review wait. Do them in this order.

| Part | What you get | Time |
|---|---|---|
| A | Your Buy Me a Coffee link | 10 min |
| B | A public web page for your privacy policy (the store requires one) | 15 min |
| C | A Chrome Web Store developer account | 15 min + one-time fee |
| D | Inkforge submitted to the store | 30 min |

The files referred to below are in this `store-kit` folder.

---

## Part A: Get your Buy Me a Coffee link

1. Go to **buymeacoffee.com** and click **Start my page** (or *Sign up*). Sign up with Google or an email address.
2. Pick your **page name**. This becomes your link, `buymeacoffee.com/your-name`. Short and brand-friendly is best, for example `pinpixels`.
3. Fill in your page:
   - **Display name:** PinPixels (or your name)
   - **About:** one or two lines, e.g. *"I build free tools for writers and developers, like Inkforge, which turns PDFs into polished Medium articles."*
   - **Profile photo:** your logo or a photo
   - **Coffee price:** keep the default unless you have a preference
4. Connect a payout method: open **Settings → Payments / Payouts** and connect **Stripe** (pays to your bank) or **PayPal**. Follow their identity checks; this is normal.
   - Buy Me a Coffee is free to join. It keeps **5%** of each tip, and Stripe or PayPal take their usual processing fee.
5. Open your page in a private/incognito window to check it works, then **copy the link**.
6. **Put the link into Inkforge.** The easiest way is to send me the link and I'll do it and rebuild the ZIP. To do it yourself:
   1. Open `ext/src/config.js` with Notepad (right-click → *Open with* → Notepad) or VS Code.
   2. Replace `YOUR_HANDLE` with your page name: `'https://buymeacoffee.com/pinpixels'`
   3. Save. In `store-kit/website/index.html`, replace `YOUR_HANDLE` the same way.
   4. Test it: open `chrome://extensions`, find Inkforge, click the **↻ reload** icon, and open the panel. The ☕ button should now appear at the top right.

---

## Part B: Put your privacy policy online (free, with GitHub Pages)

The Chrome Web Store needs a **public link** to a privacy policy. Your GitHub account can host one for free.

1. **Fill in the blanks first.** Open `store-kit/website/privacy.html` and `terms.html` in Notepad, and replace `[SUPPORT EMAIL]` with the address people should contact.
   - Tip: create a dedicated address such as `pinpixels.support@gmail.com`, so your personal inbox stays private. This address is public.
2. Go to **github.com**, sign in, click **+** (top right) → **New repository**.
   - Repository name: `inkforge`
   - Choose **Public**
   - Click **Create repository**
3. On the new repository page, click the **uploading an existing file** link. Drag in the three files from `store-kit/website` (`index.html`, `privacy.html`, `terms.html`), then click **Commit changes**.
4. Turn on GitHub Pages:
   1. In the repository, open **Settings → Pages**.
   2. Under **Build and deployment**, set *Source* to **Deploy from a branch**, *Branch* to **main**, folder **/ (root)**, then click **Save**.
5. Wait 1–3 minutes and refresh. GitHub shows *"Your site is live at `https://YOUR-GITHUB-NAME.github.io/inkforge/`."*
6. Open `https://YOUR-GITHUB-NAME.github.io/inkforge/privacy.html` in your browser to check it. **Save this link**; you'll paste it into the store.

---

## Part C: Create your Chrome Web Store developer account

1. **Choose the Google account carefully.** Google recommends a dedicated email for publishing, and **you can't change it later**. Your main Gmail is fine, or you can create a new one such as `pinpixels.dev@gmail.com`.
2. **Turn on 2-Step Verification** for that Google account at myaccount.google.com → **Security** → **2-Step Verification**. Google requires this for Chrome Web Store developers.
3. Open the **Chrome Web Store Developer Dashboard** (search for "Chrome Web Store developer dashboard", or go to `chrome.google.com/webstore/devconsole`) and sign in.
4. On the first visit, accept the **Developer Agreement**, then **pay the one-time registration fee** by card. The current amount is shown on the payment screen; it's a small one-time charge, not a subscription.
5. Open the **Account** tab:
   - **Publisher name:** `PinPixels` (shown as "Offered by" on your listing)
   - **Contact email:** enter it, click **Verify**, and click the link in the email Google sends you
   - If the dashboard asks whether you're a **trader** (an EU requirement), read the explanation on screen. A free extension with optional tips is usually **non-trader**, but choose what honestly fits your situation.
6. Optionally, on the same page, turn on email notifications for **published** items so you hear when you're approved.

---

## Part D: Upload and submit Inkforge

**Before you start:** if you changed `config.js` yourself in Part A, rebuild the upload ZIP:
1. Open the `ext` folder.
2. Select **everything inside it** (Ctrl+A). Don't zip the `ext` folder itself; `manifest.json` must sit at the top of the ZIP.
3. Right-click → **Send to → Compressed (zipped) folder** (on a Mac: right-click → *Compress*).
4. Name it `inkforge-chrome-web-store.zip`.

(If I updated it for you, just use the ZIP I sent.)

1. In the Developer Dashboard, click **+ New item** → **Choose file** → select `inkforge-chrome-web-store.zip` → **Upload**.
2. **Store listing** tab: open `LISTING.md` and copy each block into its field.
   - Description, category, language
   - **Store icon:** `images/store-icon-128.png`
   - **Screenshots:** upload the 5 `screenshot-0X-…png` files in order
   - **Small promo tile:** `images/promo-small-440x280.png`
   - **Marquee promo tile:** `images/promo-marquee-1400x560.png`
   - **Homepage / support URL:** your GitHub Pages link from Part B
3. **Privacy** tab: copy from `LISTING.md`.
   - Single purpose
   - Each permission justification
   - Remote code: **No**
   - Leave all data-type boxes unticked, and tick the three certification boxes
   - Paste your **privacy policy link** from Part B
4. **Distribution** tab: **Free**, visibility **Public**, **all regions**.
   - Want a quiet trial first? Choose **Unlisted**. Only people with the link can install it, and you can switch to Public later.
5. **Test instructions** tab: paste the short text from `LISTING.md`.
6. Click **Save draft**, then **Submit for review**.
   - The confirmation dialog has a box for publishing automatically after approval. Leave it ticked to go live as soon as it's approved, or untick it to publish manually; you then have 30 days after approval.
7. **Wait for review.** It's often a few days, and can be longer for a brand-new developer account. You'll get an email either way.

### If it's rejected

Don't worry, this is common for first submissions. The email names the policy and the reason. The usual fixes:
- **"Excessive / unused permissions":** tell me which one it names, and I'll remove it or narrow it.
- **"Missing or inaccessible privacy policy":** check the link opens in a private window.
- **"Misleading description" or "keyword spam":** trim the description.

Fix it, upload the new ZIP under **Package**, and resubmit.

---

## After you're live

1. Copy your store link (*Chrome Web Store → your item → address bar*).
2. Paste it into `store-kit/website/index.html` (replace `[CHROME WEB STORE LINK]`) and upload that file again on GitHub.
3. Add it to your Medium signature, and write a "how I built this" article *using* Inkforge, as a before/after of your PDF.

## Publishing an update later

1. Make your changes in the `ext` folder and test them: open `chrome://extensions` and click ↻ on Inkforge.
2. In a terminal opened in the project folder, run one of these. It needs Node.js; install it from nodejs.org if you don't have it.
   ```
   node scripts/release.mjs patch "Fixed: what you fixed"
   node scripts/release.mjs minor "New: what you added"
   ```
   This raises the version number, adds your notes to the in-app **What's new**, and builds `dist/inkforge-vX.Y.Z.zip`.
3. Dashboard → Inkforge → **Package** → **Upload new package** → choose that ZIP → **Submit for review**.
4. Once approved, Chrome updates everyone automatically. Users see an "Inkforge was updated" banner and your notes.
